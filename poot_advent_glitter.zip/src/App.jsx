import { useState } from "react";
import "./App.css";

export default function AdventCalendar() {
  const days = Array.from({ length: 25 }, (_, i) => i + 1);
  const [opened, setOpened] = useState({});

  const handleOpen = (day) => {
    setOpened((prev) => ({ ...prev, [day]: true }));
  };

  return (
    <div className="app-container">
      <h1 className="title">🎄 Digital Advent Calendar 🎄</h1>
      <div className="calendar-grid">
        {days.map((day) => (
          <div
            key={day}
            className="door"
            onClick={() => handleOpen(day)}
          >
            {opened[day] ? (
              <div className="inside">✨ HAPPY BIRTHDAY POOT ✨</div>
            ) : (
              <div className="day-number">Day {day}</div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
